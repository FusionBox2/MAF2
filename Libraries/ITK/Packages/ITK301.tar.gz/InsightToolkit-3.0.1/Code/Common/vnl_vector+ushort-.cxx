#include <vnl/vnl_vector.txx>
VNL_VECTOR_INSTANTIATE(unsigned short);
