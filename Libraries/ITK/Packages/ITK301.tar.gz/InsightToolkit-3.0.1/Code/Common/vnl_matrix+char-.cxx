#include <vnl/vnl_matrix.txx>
VNL_MATRIX_INSTANTIATE(char);
