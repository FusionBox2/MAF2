#include <vnl/vnl_c_vector.txx>
VNL_C_VECTOR_INSTANTIATE_ordered(signed short);
