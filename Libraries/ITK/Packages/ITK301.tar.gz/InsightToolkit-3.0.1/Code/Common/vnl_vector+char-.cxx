#include <vnl/vnl_vector.txx>
#include <vnl_complex_traits+char-.h>
VNL_VECTOR_INSTANTIATE(char);
